RIFI LIVE — النسخة المرتبطة بسيرفر Render

Server URL:
https://rif-live.onrender.com

تم ضبط واجهة الاختبار لاستخدام هذا العنوان للاتصال اللحظي.

مهم: هذا يربط الحضور/الغرفة والدردشة عبر Socket.IO. الصوت الحقيقي بين هاتفين يحتاج WebRTC/RTC مع signaling وICE/TURN أو مزود RTC؛ مجرد Socket.IO لا ينقل صوت الميكروفون.
