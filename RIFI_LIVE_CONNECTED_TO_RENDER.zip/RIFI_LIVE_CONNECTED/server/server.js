const express=require('express');
const http=require('http');
const cors=require('cors');
const {Server}=require('socket.io');
const app=express(); app.use(cors({origin:'*'}));
app.get('/',(_,res)=>res.json({app:'RIFI LIVE',status:'online',payments:false,agencies:false,withdrawals:false}));
const server=http.createServer(app);
const io=new Server(server,{cors:{origin:'*',methods:['GET','POST']}});
const rooms=new Map();
io.on('connection',socket=>{
 socket.on('joinRoom',({roomId,user})=>{
  if(!roomId||!user)return; socket.join(roomId); socket.data.roomId=roomId; socket.data.user=user;
  if(!rooms.has(roomId))rooms.set(roomId,new Map()); rooms.get(roomId).set(socket.id,user);
  io.to(roomId).emit('roomState',{users:[...rooms.get(roomId).values()]});
  socket.to(roomId).emit('userJoined',user);
 });
 socket.on('chatMessage',({roomId,text})=>{if(text)io.to(roomId).emit('systemMessage',`${socket.data.user?.name||'مستخدم'}: ${text}`)});
 socket.on('disconnect',()=>{const r=socket.data.roomId;if(!r||!rooms.has(r))return; const u=rooms.get(r).get(socket.id); rooms.get(r).delete(socket.id); io.to(r).emit('roomState',{users:[...rooms.get(r).values()]}); if(u)io.to(r).emit('userLeft',u);});
});
server.listen(process.env.PORT||3000,()=>console.log('RIFI LIVE server online'));
